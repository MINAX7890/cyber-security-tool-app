import sys
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import hashlib
import re
import threading
import random
import string
from cryptography.fernet import Fernet

class PasswordSecurityTool:
    def __init__(self, root):
        # --- Window Setup ---
        self.root = root
        self.root.title("Password Security Suite")
        self.root.geometry("650x700")
        self.root.configure(bg="#f0f5f9")
        self.root.resizable(False, False)
        
        # Set application icon (for PyInstaller)
        try:
            # Check if running as bundled executable
            if getattr(sys, 'frozen', False):
                base_path = sys._MEIPASS
            else:
                base_path = os.path.dirname(os.path.abspath(__file__))
                
            # You'll need to include an icon file with your PyInstaller bundle
            icon_path = os.path.join(base_path, "icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(icon_path)
        except Exception:
            pass  # Icon loading is non-critical
        
        # --- Variables ---
        self.hash_algorithms = ['MD5', 'SHA1', 'SHA256', 'SHA512']
        self.selected_algorithm = tk.StringVar(value='SHA256')
        self.show_password = tk.BooleanVar(value=False)
        self.cracking_animation = False
        self.password_length = tk.IntVar(value=16)
        
        # --- Initialize Cryptography ---
        self.load_or_create_key()
        
        # --- Style ---
        self.configure_styles()
        
        # --- Create UI ---
        self.create_notebook()
    
    def configure_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background='#f0f5f9')
        style.configure('TLabel', background='#f0f5f9', font=('Helvetica', 11))
        style.configure('Header.TLabel', font=('Helvetica', 14, 'bold'))
        style.configure('TButton', font=('Helvetica', 10))
        for color, name in [('#007bff', 'Primary'), ('#28a745', 'Success'), 
                           ('#ffc107', 'Warning'), ('#17a2b8', 'Info'),
                           ('#6f42c1', 'Purple')]:
            style.configure(f'{name}.TButton', background=color)
    
    def create_notebook(self):
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create tabs
        self.strength_tab = ttk.Frame(notebook, style='TFrame')
        self.cracker_tab = ttk.Frame(notebook, style='TFrame')
        self.crypto_tab = ttk.Frame(notebook, style='TFrame')
        self.decrypt_tab = ttk.Frame(notebook, style='TFrame')
        
        notebook.add(self.strength_tab, text="Password Strength")
        notebook.add(self.cracker_tab, text="Hash Cracker")
        notebook.add(self.crypto_tab, text="Encryption")
        notebook.add(self.decrypt_tab, text="Decryption")
        
        # Setup each tab
        self.setup_strength_tab()
        self.setup_cracker_tab()
        self.setup_crypto_tab()
        self.setup_decrypt_tab()
    
    def get_key_path(self):
        """Get the path to the secret key file"""
        try:
            # Check if running as bundled executable
            if getattr(sys, 'frozen', False):
                # PyInstaller creates a temp folder and stores path in _MEIPASS
                base_dir = os.path.dirname(sys.executable)
            else:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                
            app_dir = os.path.join(base_dir, "password_data")
            if not os.path.exists(app_dir):
                try:
                    os.makedirs(app_dir)
                except OSError:
                    # Fallback to user directory if we can't write to app directory
                    home_dir = os.path.expanduser("~")
                    app_dir = os.path.join(home_dir, ".password_security_tool")
                    if not os.path.exists(app_dir):
                        os.makedirs(app_dir)
                        
            return os.path.join(app_dir, "secret.key")
        except Exception as e:
            messagebox.showwarning("Path Error", f"Could not set data path: {e}")
            # Fallback to current directory
            return "secret.key"
    
    def setup_strength_tab(self):
        """Setup password strength checker tab"""
        ttk.Label(self.strength_tab, text="Password Strength Checker & Generator", 
                 style='Header.TLabel').pack(pady=(15, 10))
        
        # Password entry frame
        entry_frame = ttk.Frame(self.strength_tab)
        entry_frame.pack(pady=5, fill=tk.X, padx=15)
        
        ttk.Label(entry_frame, text="Enter Password:").pack(anchor=tk.W)
        
        input_frame = ttk.Frame(entry_frame)
        input_frame.pack(fill=tk.X, pady=3)
        
        self.password_entry = ttk.Entry(input_frame, width=35, show="*")
        self.password_entry.pack(side=tk.LEFT, padx=(0, 5), fill=tk.X, expand=True)
        
        ttk.Checkbutton(input_frame, text="Show", variable=self.show_password, 
                       command=self.toggle_password_visibility).pack(side=tk.LEFT)
        
        # Button & generator options frame
        control_frame = ttk.Frame(self.strength_tab)
        control_frame.pack(pady=5, fill=tk.X, padx=15)
        
        ttk.Label(control_frame, text="Length:").pack(side=tk.LEFT)
        ttk.Spinbox(control_frame, from_=8, to=32, textvariable=self.password_length, 
                   width=3).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(control_frame, text="Generate", style='Success.TButton',
                  command=self.generate_password).pack(side=tk.RIGHT, padx=3)
        ttk.Button(control_frame, text="Check Strength", style='Primary.TButton',
                  command=self.check_password_strength).pack(side=tk.RIGHT, padx=3)
        
        # Results frame
        results_frame = ttk.Frame(self.strength_tab)
        results_frame.pack(pady=5, fill=tk.BOTH, padx=15)
        
        self.result_label = ttk.Label(results_frame, text="Enter a password to check its strength",
                                    wraplength=500)
        self.result_label.pack(anchor=tk.CENTER, pady=5)
        
        # Strength meter
        self.meter = ttk.Progressbar(results_frame, length=350, mode='determinate')
        self.meter.pack(pady=5)
        
        # Tips frame
        tips_frame = ttk.LabelFrame(self.strength_tab, text="Password Tips")
        tips_frame.pack(pady=5, fill=tk.X, padx=15)
        
        tips = ("• Use 12+ characters • Mix upper & lowercase\n"
               "• Include numbers & special chars • Avoid common patterns\n"
               "• Don't reuse passwords across sites")
        
        ttk.Label(tips_frame, text=tips, justify=tk.LEFT).pack(pady=5, padx=5)
    
    def setup_cracker_tab(self):
        """Setup hash cracker tab"""
        ttk.Label(self.cracker_tab, text="Password Hash Cracker", 
                 style='Header.TLabel').pack(pady=(15, 5))
        
        ttk.Label(self.cracker_tab, text="For educational purposes only.",
                 foreground="red").pack(pady=(0, 5))
        
        # Hash input
        input_frame = ttk.Frame(self.cracker_tab)
        input_frame.pack(pady=5, fill=tk.X, padx=15)
        
        ttk.Label(input_frame, text="Hash:").pack(side=tk.LEFT, padx=(0, 5))
        self.hash_entry = ttk.Entry(input_frame, width=40, font=('Courier', 10))
        self.hash_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Algorithm & button
        control_frame = ttk.Frame(self.cracker_tab)
        control_frame.pack(pady=5, padx=15, fill=tk.X)
        
        ttk.Label(control_frame, text="Algorithm:").pack(side=tk.LEFT)
        ttk.Combobox(control_frame, textvariable=self.selected_algorithm,
                    values=self.hash_algorithms, state="readonly", width=8).pack(side=tk.LEFT, padx=5)
        
        self.crack_button = ttk.Button(control_frame, text="Select Wordlist & Crack", 
                                      style='Warning.TButton', command=self.start_crack_thread)
        self.crack_button.pack(side=tk.RIGHT)
        
        # Results
        result_frame = ttk.Frame(self.cracker_tab)
        result_frame.pack(pady=5, fill=tk.X, padx=15)
        
        self.wordlist_label = ttk.Label(result_frame, text="No wordlist selected")
        self.wordlist_label.pack(side=tk.LEFT)
        
        self.cracking_result = ttk.Label(result_frame, text="")
        self.cracking_result.pack(pady=5)
        
        # Hash Info
        info_frame = ttk.LabelFrame(self.cracker_tab, text="Hash Information")
        info_frame.pack(pady=5, fill=tk.X, padx=15)
        
        hash_info = ("• MD5: 32 hex chars - Fast but insecure\n"
                    "• SHA1: 40 hex chars - Legacy, vulnerable\n"
                    "• SHA256: 64 hex chars - Good security\n"
                    "• SHA512: 128 hex chars - Strongest")
        
        ttk.Label(info_frame, text=hash_info, justify=tk.LEFT).pack(pady=5, padx=5)
    
    def setup_crypto_tab(self):
        """Setup encryption tab"""
        ttk.Label(self.crypto_tab, text="AES Encryption", 
                 style='Header.TLabel').pack(pady=(15, 10))
        
        # Key status
        self.key_status = ttk.Label(self.crypto_tab, text="")
        self.key_status.pack(pady=3)
        
        # Encryption section
        enc_frame = ttk.LabelFrame(self.crypto_tab, text="Encryption")
        enc_frame.pack(pady=5, fill=tk.X, padx=15)
        
        ttk.Label(enc_frame, text="Message to Encrypt:").pack(anchor=tk.W, padx=5, pady=(5, 2))
        self.encrypt_entry = tk.Text(enc_frame, height=3, width=45)
        self.encrypt_entry.pack(padx=5, pady=3, fill=tk.X)
        
        ttk.Button(enc_frame, text="Encrypt & Save", style='Info.TButton',
                  command=self.encrypt_message).pack(pady=5)
        
        self.encrypted_result = ttk.Label(enc_frame, text="", wraplength=550)
        self.encrypted_result.pack(pady=5, padx=5)
        
        # Current secret.key content display
        content_frame = ttk.LabelFrame(self.crypto_tab, text="Current Encrypted Content")
        content_frame.pack(pady=5, fill=tk.X, padx=15)
        
        self.key_content = tk.Text(content_frame, height=3, width=45, state=tk.DISABLED)
        self.key_content.pack(padx=5, pady=3, fill=tk.X)
        
        # Load current content
        self.load_current_key_content()
    
    def setup_decrypt_tab(self):
        """Setup decryption tab"""
        ttk.Label(self.decrypt_tab, text="AES Decryption", 
                 style='Header.TLabel').pack(pady=(15, 10))
        
        # Key status
        self.decrypt_key_status = ttk.Label(self.decrypt_tab, text="")
        self.decrypt_key_status.pack(pady=3)
        
        # Decryption section
        dec_frame = ttk.LabelFrame(self.decrypt_tab, text="Decryption")
        dec_frame.pack(pady=5, fill=tk.X, padx=15)
        
        load_frame = ttk.Frame(dec_frame)
        load_frame.pack(fill=tk.X, pady=3)
        ttk.Button(load_frame, text="Load Encrypted Message", 
                  command=self.load_encrypted_message).pack(side=tk.LEFT)
        
        ttk.Label(dec_frame, text="Encrypted Text:").pack(anchor=tk.W, padx=5, pady=(5, 2))
        self.decrypt_entry = tk.Text(dec_frame, height=3, width=45)
        self.decrypt_entry.pack(padx=5, pady=3, fill=tk.X)
        
        ttk.Button(dec_frame, text="Decrypt", style='Purple.TButton',
                  command=self.decrypt_message).pack(pady=5)
        
        self.decrypted_result = ttk.Label(dec_frame, text="", wraplength=550)
        self.decrypted_result.pack(pady=5, padx=5)
        
        # Add export button for decrypted content
        ttk.Button(dec_frame, text="Export Decrypted Text", 
                   command=self.export_decrypted_text).pack(pady=5)
    
    def export_decrypted_text(self):
        """Export decrypted text to a file"""
        decrypted_text = self.decrypted_result.cget("text")
        if not decrypted_text or not decrypted_text.startswith("🔓 Decrypted:"):
            messagebox.showwarning("Export Error", "No decrypted text to export")
            return
            
        try:
            # Extract just the decrypted content
            text_to_save = decrypted_text.replace("🔓 Decrypted: ", "")
            
            file_path = filedialog.asksaveasfilename(
                title="Export Decrypted Text",
                defaultextension=".txt",
                filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
                initialfile="decrypted.txt"
            )
            
            if not file_path:
                return
                
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(text_to_save)
                
            messagebox.showinfo("Export Successful", f"Text exported to: {file_path}")
        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export: {e}")
    
    def check_password_strength(self):
        """Check and display password strength"""
        password = self.password_entry.get()
        if not password:
            messagebox.showwarning("Input Error", "Please enter a password.")
            return
        
        # Calculate strength score (0-5)
        strength = 0
        feedback = []
        
        # Length check
        if len(password) >= 12:
            strength += 1
        elif len(password) >= 8:
            strength += 0.5
            feedback.append("Consider using a longer password (12+ chars)")
        else:
            feedback.append("Password is too short (aim for 12+ chars)")
        
        # Character variety checks
        if re.search(r"[a-z]", password): strength += 1  
        else: feedback.append("Add lowercase letters")
            
        if re.search(r"[A-Z]", password): strength += 1
        else: feedback.append("Add uppercase letters")
            
        if re.search(r"\d", password): strength += 1
        else: feedback.append("Add numbers")
            
        if re.search(r"[@$!%*?&#]", password): strength += 1
        else: feedback.append("Add special characters (@$!%*?&#)")
        
        # Common patterns check
        common_patterns = [r"12345", r"qwerty", r"password", r"admin", r"welcome"]
        for pattern in common_patterns:
            if re.search(pattern, password.lower()):
                strength -= 1
                feedback.append("Avoid common patterns/words")
                break
        
        # Update meter
        strength_pct = max(0, min(100, strength * 20))
        self.meter.config(value=strength_pct)
        
        # Set text and color based on strength
        if strength <= 2:
            strength_text = "Weak Password"
            time_text = "Could be cracked quickly"
            color = "red"
        elif strength <= 3:
            strength_text = "Moderate Password"
            time_text = "Could take hours or days to crack"
            color = "orange"
        elif strength <= 4:
            strength_text = "Strong Password"
            time_text = "Could take years to crack"
            color = "blue"
        else:
            strength_text = "Very Strong Password"
            time_text = "Would take centuries to crack"
            color = "green"
            
        result = f"{strength_text}\n{time_text}"
        
        if feedback:
            result += "\n\nSuggestions: " + ", ".join(f"{item.lower()}" for item in feedback)
        
        self.result_label.config(text=result, foreground=color)
    
    def generate_password(self):
        """Generate and display a strong password"""
        length = self.password_length.get()
        
        # Ensure at least one of each character type
        lowercase = random.choice(string.ascii_lowercase)
        uppercase = random.choice(string.ascii_uppercase)
        digit = random.choice(string.digits)
        special = random.choice("!@#$%^&*()-_=+")
        
        # Fill the rest with random characters
        remaining_length = length - 4
        remaining_chars = ''.join(random.choice(
            string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
        ) for _ in range(remaining_length))
        
        # Combine and shuffle
        all_chars = lowercase + uppercase + digit + special + remaining_chars
        password_list = list(all_chars)
        random.shuffle(password_list)
        password = ''.join(password_list)
        
        # Update entry and check strength
        self.password_entry.delete(0, tk.END)
        self.password_entry.insert(0, password)
        self.check_password_strength()
    
    def toggle_password_visibility(self):
        """Toggle password field visibility"""
        self.password_entry.config(show="" if self.show_password.get() else "*")
    
    def get_hash_function(self, name):
        """Return appropriate hash function"""
        name = name.lower()
        if name == 'md5': return hashlib.md5
        elif name == 'sha1': return hashlib.sha1
        elif name == 'sha256': return hashlib.sha256
        elif name == 'sha512': return hashlib.sha512
        else: raise ValueError(f"Unsupported hash algorithm: {name}")
    
    def crack_hash(self, hash_to_crack, wordlist_path, hash_func):
        """Attempt to crack a hash using a wordlist"""
        try:
            found = False
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as file:
                for i, word in enumerate(file):
                    if i % 1000 == 0:  # Update status periodically
                        self.update_crack_status(f"Trying... ({i:,} checked)")
                    
                    word = word.strip()
                    if hash_func(word.encode()).hexdigest() == hash_to_crack:
                        found = True
                        self.cracking_result.config(text=f"✅ Found: {word}", foreground="green")
                        break
            
            if not found:
                self.cracking_result.config(text="❌ Password not found.", foreground="red")
        
        except Exception as e:
            self.cracking_result.config(text=f"Error: {e}", foreground="red")
    
    def update_crack_status(self, message):
        """Update the cracking status message"""
        self.cracking_result.config(text=message, foreground="blue")
    
    def threaded_crack(self, hash_value, file_path, algorithm):
        """Run hash cracking in a separate thread"""
        hash_func = self.get_hash_function(algorithm)
        self.crack_hash(hash_value, file_path, hash_func)
        self.stop_animation()
        self.crack_button.config(state="normal")
    
    def start_crack_thread(self):
        """Start the hash cracking process"""
        hash_value = self.hash_entry.get().strip()
        algorithm = self.selected_algorithm.get()
        
        if not hash_value:
            messagebox.showwarning("Input Error", "Please enter a hash.")
            return
        
        file_path = filedialog.askopenfilename(
            title="Select Wordlist", 
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        
        if not file_path:
            return
        
        self.wordlist_label.config(text=f"List: {os.path.basename(file_path)}")
        self.cracking_result.config(text="⏳ Starting...", foreground="blue")
        
        self.crack_button.config(state="disabled")
        self.animate_cracking()
        threading.Thread(
            target=self.threaded_crack, 
            args=(hash_value, file_path, algorithm)
        ).start()
    
    def animate_cracking(self):
        """Show animated spinner while cracking"""
        self.cracking_animation = True
        spinner = ['|', '/', '-', '\\']
        idx = 0
        
        def update_spinner():
            nonlocal idx
            if self.cracking_animation:
                self.cracking_result.config(
                    text=f"⏳ Cracking... {spinner[idx % 4]}", 
                    foreground="blue"
                )
                idx += 1
                self.root.after(200, update_spinner)
        
        update_spinner()
    
    def stop_animation(self):
        """Stop the cracking animation"""
        self.cracking_animation = False
    
    def load_or_create_key(self):
        """Load or create an encryption key"""
        key_path = self.get_key_path()
        
        try:
            # Create a dedicated key file
            key_dir = os.path.dirname(key_path)
            key_file = os.path.join(key_dir, "cipher.key")
            
            if not os.path.exists(key_file):
                # Create directory if it doesn't exist
                if not os.path.exists(key_dir):
                    os.makedirs(key_dir)
                
                # Generate and save new key
                key = Fernet.generate_key()
                with open(key_file, "wb") as f:
                    f.write(key)
                self.key_status_text = f"✅ New encryption key created"
            else:
                # Load existing key
                with open(key_file, "rb") as f:
                    key = f.read()
                self.key_status_text = f"✅ Encryption key loaded"
            
            # Make sure secret.key exists
            if not os.path.exists(key_path):
                with open(key_path, "w") as f:
                    f.write("")
            
            self.cipher_key = key
            
            # Update key status labels if they exist
            if hasattr(self, 'key_status'):
                self.key_status.config(text=self.key_status_text, foreground="green")
            if hasattr(self, 'decrypt_key_status'):
                self.decrypt_key_status.config(text=self.key_status_text, foreground="green")
                
            return key
        except Exception as e:
            error_msg = f"Key error: {e}"
            if hasattr(self, 'key_status'):
                self.key_status.config(text=f"❌ {error_msg}", foreground="red")
            # Create a default key in memory as fallback
            self.cipher_key = Fernet.generate_key()
            return self.cipher_key
    
    def load_current_key_content(self):
        """Load and display current secret.key content"""
        try:
            key_path = self.get_key_path()
            if os.path.exists(key_path):
                with open(key_path, "r") as f:
                    content = f.read()
                
                self.key_content.config(state=tk.NORMAL)
                self.key_content.delete(1.0, tk.END)
                self.key_content.insert(tk.END, content if content else "[Empty]")
                self.key_content.config(state=tk.DISABLED)
            else:
                self.key_content.config(state=tk.NORMAL)
                self.key_content.delete(1.0, tk.END)
                self.key_content.insert(tk.END, "[No file yet]")
                self.key_content.config(state=tk.DISABLED)
        except Exception as e:
            print(f"Error loading key content: {e}")
    
    def load_encrypted_message(self):
        """Load encrypted message from secret.key to decrypt entry field"""
        try:
            with open(self.get_key_path(), "r") as file:
                encrypted_message = file.read().strip()
            
            if encrypted_message:
                self.decrypt_entry.delete("1.0", tk.END)
                self.decrypt_entry.insert("1.0", encrypted_message)
                messagebox.showinfo("Load Successful", "Encrypted message loaded")
            else:
                messagebox.showinfo("Empty File", "No encrypted message found")
        except Exception as e:
            messagebox.showerror("Load Error", f"Failed to load: {e}")
    
    def encrypt_message(self):
        """Encrypt the user's message and automatically save to secret.key"""
        message = self.encrypt_entry.get("1.0", tk.END).strip()
        if not message:
            messagebox.showwarning("Input Error", "Please enter a message to encrypt.")
            return
        
        try:
            f = Fernet(self.cipher_key)
            encrypted = f.encrypt(message.encode()).decode()
            
            # Save encrypted message to secret.key
            with open(self.get_key_path(), "w") as file:
                file.write(encrypted)
                
            self.encrypted_result.config(
                text=f"🔒 Encrypted and saved to secure storage", 
                foreground="green"
            )
            
            # Clear the input field
            self.encrypt_entry.delete("1.0", tk.END)
            
            # Update the displayed content
            self.load_current_key_content()
            
        except Exception as e:
            self.encrypted_result.config(
                text=f"Error: {e}", 
                foreground="red"
            )
    
    def decrypt_message(self):
        """Decrypt the message"""
        try:
            encrypted_message = self.decrypt_entry.get("1.0", tk.END).strip()
                
            if not encrypted_message:
                messagebox.showwarning("Input Error", "No encrypted message found.")
                return
            
            # Create a new Fernet object with the current key
            f = Fernet(self.cipher_key)
            
            # Decrypt the message
            decrypted = f.decrypt(encrypted_message.encode()).decode()
            self.decrypted_result.config(
                text=f"🔓 Decrypted: {decrypted}", 
                foreground="green"
            )
        except Exception as e:
            self.decrypted_result.config(
                text=f"Error: Invalid ciphertext or key", 
                foreground="red"
            )

def resource_path(relative_path):
    """Get absolute path to resource for PyInstaller"""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def main():
    root = tk.Tk()
    try:
        app = PasswordSecurityTool(root)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Fatal Error", f"Application failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()